# Available Translations

* [中文版 (Chinese)](https://github.com/llh911001/mostly-adequate-guide-chinese)  by Linghao Li @llh911001
* [Русский (Russian)](https://github.com/MostlyAdequate/mostly-adequate-guide-ru)  by Maksim Filippov @maksimf
* [Français (French)](https://github.com/MostlyAdequate/mostly-adequate-guide-fr) by Benkort Matthias @KtorZ
* [Português (Portuguese)](https://github.com/MostlyAdequate/mostly-adequate-guide-pt-BR) by Palmer Oliveira @expalmer
* [Español (Spanish)](https://github.com/MostlyAdequate/mostly-adequate-guide-es) by Gustavo Marin @guumaster
* [Italiano (Italian)](https://github.com/MostlyAdequate/mostly-adequate-guide-it) by Elia Gentili @eliagentili

## Creating new Translations

See [Creating new translations](CONTRIBUTING.md#Translations)
