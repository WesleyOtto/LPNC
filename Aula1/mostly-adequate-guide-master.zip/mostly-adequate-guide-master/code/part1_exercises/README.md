Part 1 Exercises
==================

**Installation**:
`npm install`

**Running tests**:
Tests are located in their corresponding folders.  To run:

```
cd exercises/curry
mocha *spec.js
```

Some will fail and some will pass. You'll need to edit the exercises until the tests pass.
